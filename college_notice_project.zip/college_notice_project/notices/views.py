from django.shortcuts import render
from .models import Notice
from django.utils import timezone
from datetime import date


def home(request):
    category = request.GET.get('category')
    search = request.GET.get('search')

    notices = Notice.objects.filter(expiry_date__gte=timezone.now()).order_by('-created_at')

    if category:
        notices = notices.filter(category=category)

    if search:
        notices = notices.filter(title__icontains=search)

    return render(request, 'notices/home.html', {
    'notices': notices,
    'today': date.today().strftime("%Y-%m-%d")
})

