from django.db import models

class Notice(models.Model):
    CATEGORY_CHOICES = [
        ('Exam', 'Exam'),
        ('Event', 'Event'),
        ('Holiday', 'Holiday'),
        ('General', 'General'),
    ]

    title = models.CharField(max_length=200)
    content = models.TextField()
    category = models.CharField(max_length=20, choices=CATEGORY_CHOICES)
    department = models.CharField(max_length=100, default="Computer Science")
    important = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    expiry_date = models.DateField()
    pdf = models.FileField(upload_to='notice_pdfs/', blank=True, null=True)


    def __str__(self):
        return self.title
